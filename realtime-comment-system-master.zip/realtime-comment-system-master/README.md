# realtime-comment-system
In this tutorial we have built a realtime comment system.

#### Demo: https://realtime-comment-system.herokuapp.com/

## Installation 
After download or clone run `npm install` to install all the dependancies.


🙏 If you find this repo helpful then don't forget to give a start ❇️ to this repository. :)
